import React, { useState, useEffect } from 'react';
import { Search, TrendingUp, TrendingDown, DollarSign, Activity, Brain, AlertCircle } from 'lucide-react';
import StockSelector from './StockSelector';
import AnalysisReport from './AnalysisReport';
import PredictionModels from './PredictionModels';
import NewsSection from './NewsSection';
import { StockData, PredictionResult } from '../types/stock';
import { mockStockData, mockPredictions, mockNews } from '../data/mockData';

const StockAnalysisDashboard: React.FC = () => {
  const [selectedStock, setSelectedStock] = useState<string>('');
  const [selectedStocks, setSelectedStocks] = useState<string[]>([]);
  const [isMultiStock, setIsMultiStock] = useState(false);
  const [stockData, setStockData] = useState<StockData | null>(null);
  const [predictions, setPredictions] = useState<PredictionResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');

  const handleStockSelect = async (symbol: string) => {
    setSelectedStock(symbol);
    setLoading(true);
    setError('');
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const data = mockStockData[symbol] || mockStockData['AAPL'];
      const predictionResults = mockPredictions[symbol] || mockPredictions['AAPL'];
      
      setStockData(data);
      setPredictions(predictionResults);
    } catch (err) {
      setError('Failed to fetch stock data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleMultiStockSelect = async (symbols: string[]) => {
    setSelectedStocks(symbols);
    setIsMultiStock(true);
    setLoading(true);
    setError('');
    
    try {
      // For demo, we'll analyze the first stock in detail
      if (symbols.length > 0) {
        await handleStockSelect(symbols[0]);
      }
    } catch (err) {
      setError('Failed to fetch multi-stock data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-2xl mr-4">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              StockMind AI
            </h1>
          </div>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Advanced AI-powered stock analysis with multiple prediction models and comprehensive market insights
          </p>
        </div>

        {/* Stock Selector */}
        <StockSelector 
          onStockSelect={handleStockSelect} 
          selectedStocks={selectedStocks}
          onMultiStockSelect={handleMultiStockSelect}
        />

        {/* Multi-Stock Comparison Header */}
        {isMultiStock && selectedStocks.length > 1 && (
          <div className="mb-8">
            <div className="bg-gradient-to-r from-purple-500/10 to-indigo-500/10 border border-purple-500/20 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-xl font-bold text-white mb-2">
                Comparing {selectedStocks.length} Stocks
              </h2>
              <div className="flex flex-wrap gap-2">
                {selectedStocks.map((symbol, index) => (
                  <span key={symbol} className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-3 py-1 rounded-full text-sm">
                    {symbol}
                  </span>
                ))}
              </div>
              <p className="text-gray-300 text-sm mt-2">
                Detailed analysis shown for {selectedStock} • Multi-stock comparison features coming soon
              </p>
            </div>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
              <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-t-purple-500 rounded-full animate-spin animation-delay-150"></div>
            </div>
            <p className="text-gray-300 mt-4 text-lg">Analyzing {selectedStock}...</p>
            <p className="text-gray-400 text-sm mt-2">Running multiple AI models</p>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-6 mb-8">
            <div className="flex items-center">
              <AlertCircle className="w-6 h-6 text-red-400 mr-3" />
              <p className="text-red-300">{error}</p>
            </div>
          </div>
        )}

        {/* Analysis Results */}
        {stockData && !loading && (
          <div className="space-y-8">
            {/* Key Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-300 text-sm font-medium">Current Price</p>
                    <p className="text-2xl font-bold text-white">${stockData.currentPrice}</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-400" />
                </div>
                <p className="text-green-400 text-sm mt-2">+{stockData.dailyChange}% today</p>
              </div>

              <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-300 text-sm font-medium">Market Cap</p>
                    <p className="text-2xl font-bold text-white">{stockData.marketCap}</p>
                  </div>
                  <Activity className="w-8 h-8 text-blue-400" />
                </div>
                <p className="text-blue-400 text-sm mt-2">Volume: {stockData.volume}</p>
              </div>

              <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-300 text-sm font-medium">52W High</p>
                    <p className="text-2xl font-bold text-white">${stockData.high52w}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-purple-400" />
                </div>
                <p className="text-purple-400 text-sm mt-2">Low: ${stockData.low52w}</p>
              </div>

              <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-xl p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-300 text-sm font-medium">P/E Ratio</p>
                    <p className="text-2xl font-bold text-white">{stockData.peRatio}</p>
                  </div>
                  <TrendingDown className="w-8 h-8 text-orange-400" />
                </div>
                <p className="text-orange-400 text-sm mt-2">Volatility: {stockData.volatility}%</p>
              </div>
            </div>

            {/* Analysis Report */}
            <AnalysisReport stockData={stockData} />

            {/* Prediction Models */}
            <PredictionModels predictions={predictions} currentPrice={stockData.currentPrice} />

            {/* News Section */}
            <NewsSection symbol={selectedStock} />
          </div>
        )}
      </div>
    </div>
  );
};

export default StockAnalysisDashboard;