import React from 'react';
import { TrendingUp, TrendingDown, Activity, Target, AlertTriangle, CheckCircle } from 'lucide-react';
import { StockData } from '../types/stock';

interface AnalysisReportProps {
  stockData: StockData;
}

const AnalysisReport: React.FC<AnalysisReportProps> = ({ stockData }) => {
  const isIndianStock = ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'WIPRO', 'ICICIBANK', 'SBIN', 'ITC', 'HINDUNILVR', 'BAJFINANCE'].includes(stockData.symbol);
  const currencySymbol = isIndianStock ? '₹' : '$';
  
  const getTradingSuggestion = () => {
    const strength = stockData.technicalIndicators.rsi > 70 ? 'SELL' : 
                     stockData.technicalIndicators.rsi < 30 ? 'BUY' : 'HOLD';
    
    const color = strength === 'BUY' ? 'text-green-400' : 
                  strength === 'SELL' ? 'text-red-400' : 'text-yellow-400';
    
    const bgColor = strength === 'BUY' ? 'from-green-500/20 to-emerald-500/20 border-green-500/30' : 
                    strength === 'SELL' ? 'from-red-500/20 to-orange-500/20 border-red-500/30' : 
                    'from-yellow-500/20 to-orange-500/20 border-yellow-500/30';

    return { strength, color, bgColor };
  };

  const suggestion = getTradingSuggestion();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Technical Analysis */}
      <div className="lg:col-span-2 bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm">
        <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
          <Activity className="w-6 h-6 mr-3 text-blue-400" />
          Technical Analysis
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Technical Indicators */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-300 mb-4">Key Indicators</h3>
            
            <div className="bg-gray-800/50 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-300">RSI (14)</span>
                <span className={`font-bold ${stockData.technicalIndicators.rsi > 70 ? 'text-red-400' : 
                  stockData.technicalIndicators.rsi < 30 ? 'text-green-400' : 'text-yellow-400'}`}>
                  {stockData.technicalIndicators.rsi}
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${stockData.technicalIndicators.rsi > 70 ? 'bg-red-400' : 
                    stockData.technicalIndicators.rsi < 30 ? 'bg-green-400' : 'bg-yellow-400'}`}
                  style={{ width: `${stockData.technicalIndicators.rsi}%` }}
                ></div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">MACD</span>
                <span className={`font-bold ${stockData.technicalIndicators.macd > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {stockData.technicalIndicators.macd > 0 ? '+' : ''}{stockData.technicalIndicators.macd}
                </span>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Bollinger Position</span>
                <span className="font-bold text-blue-400">{stockData.technicalIndicators.bollingerPosition}%</span>
              </div>
            </div>
          </div>

          {/* Moving Averages */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-300 mb-4">Moving Averages</h3>
            
            {Object.entries(stockData.movingAverages).map(([period, value]) => (
              <div key={period} className="bg-gray-800/50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">{period}</span>
                  <div className="text-right">
                    <span className="font-bold text-white">{currencySymbol}{value}</span>
                    <div className="flex items-center mt-1">
                      {stockData.currentPrice > value ? (
                        <>
                          <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                          <span className="text-green-400 text-sm">Above</span>
                        </>
                      ) : (
                        <>
                          <TrendingDown className="w-4 h-4 text-red-400 mr-1" />
                          <span className="text-red-400 text-sm">Below</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Assessment */}
        <div className="mt-6 pt-6 border-t border-gray-700/50">
          <h3 className="text-lg font-semibold text-gray-300 mb-4">Risk Assessment</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-400 mb-2">{stockData.volatility}%</div>
              <div className="text-gray-300 text-sm">Volatility</div>
            </div>
            <div className="text-center p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl font-bold text-purple-400 mb-2">{stockData.beta || '1.2'}</div>
              <div className="text-gray-300 text-sm">Beta</div>
            </div>
            <div className="text-center p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl font-bold text-blue-400 mb-2">{stockData.sharpeRatio || '0.85'}</div>
              <div className="text-gray-300 text-sm">Sharpe Ratio</div>
            </div>
          </div>
        </div>
      </div>

      {/* Trading Recommendation */}
      <div className="space-y-6">
        {/* Main Recommendation */}
        <div className={`bg-gradient-to-br ${suggestion.bgColor} border rounded-xl p-6 backdrop-blur-sm`}>
          <div className="text-center">
            <div className="mb-4">
              {suggestion.strength === 'BUY' && <CheckCircle className="w-12 h-12 text-green-400 mx-auto" />}
              {suggestion.strength === 'SELL' && <AlertTriangle className="w-12 h-12 text-red-400 mx-auto" />}
              {suggestion.strength === 'HOLD' && <Target className="w-12 h-12 text-yellow-400 mx-auto" />}
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Recommendation</h3>
            <div className={`text-3xl font-bold ${suggestion.color} mb-4`}>
              {suggestion.strength}
            </div>
            <p className="text-gray-300 text-sm">
              {suggestion.strength === 'BUY' && 'Technical indicators suggest potential upside'}
              {suggestion.strength === 'SELL' && 'Technical indicators suggest potential downside'}
              {suggestion.strength === 'HOLD' && 'Mixed signals, consider waiting'}
            </p>
          </div>
        </div>

        {/* Price Targets */}
        <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Target className="w-5 h-5 mr-2 text-purple-400" />
            Price Targets
          </h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Support Level</span>
              <span className="font-bold text-red-400">{currencySymbol}{stockData.supportLevel}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Current Price</span>
              <span className="font-bold text-white">{currencySymbol}{stockData.currentPrice}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Resistance Level</span>
              <span className="font-bold text-green-400">{currencySymbol}{stockData.resistanceLevel}</span>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-700/50">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-300 text-sm">Price Range</span>
              <span className="text-gray-400 text-sm">Support → Resistance</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-3 relative">
              <div className="absolute left-0 w-2 h-3 bg-red-400 rounded-l-full"></div>
              <div className="absolute right-0 w-2 h-3 bg-green-400 rounded-r-full"></div>
              <div 
                className="absolute w-2 h-3 bg-white rounded-full transform -translate-x-1/2"
                style={{ 
                  left: `${((stockData.currentPrice - stockData.supportLevel) / 
                    (stockData.resistanceLevel - stockData.supportLevel)) * 100}%` 
                }}
              ></div>
            </div>
          </div>
        </div>

        {/* Performance Summary */}
        <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm">
          <h3 className="text-lg font-semibold text-white mb-4">Performance</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">1 Day</span>
              <span className={`font-bold ${stockData.dailyChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {stockData.dailyChange >= 0 ? '+' : ''}{stockData.dailyChange}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">1 Week</span>
              <span className="font-bold text-green-400">+{stockData.weeklyChange || '3.24'}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">1 Month</span>
              <span className="font-bold text-green-400">+{stockData.monthlyChange || '8.76'}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">YTD</span>
              <span className="font-bold text-green-400">+{stockData.ytdChange || '15.43'}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisReport;