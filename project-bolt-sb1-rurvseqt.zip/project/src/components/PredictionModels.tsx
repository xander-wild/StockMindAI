import React, { useState } from 'react';
import { Brain, TrendingUp, Activity, Zap, Target, BarChart3 } from 'lucide-react';
import { PredictionResult } from '../types/stock';

interface PredictionModelsProps {
  predictions: PredictionResult[];
  currentPrice: number;
}

const PredictionModels: React.FC<PredictionModelsProps> = ({ predictions, currentPrice }) => {
  const [selectedModel, setSelectedModel] = useState<string>('all');
  
  // Determine if this is an Indian stock based on price range (rough heuristic)
  const isIndianStock = currentPrice > 100; // Most Indian stocks are above ₹100
  const currencySymbol = isIndianStock ? '₹' : '$';

  const getModelIcon = (model: string) => {
    switch (model) {
      case 'Random Forest': return <Activity className="w-5 h-5" />;
      case 'XGBoost': return <Zap className="w-5 h-5" />;
      case 'SVR': return <Target className="w-5 h-5" />;
      case 'GBM': return <BarChart3 className="w-5 h-5" />;
      case 'ARIMA': return <TrendingUp className="w-5 h-5" />;
      default: return <Brain className="w-5 h-5" />;
    }
  };

  const getModelColor = (model: string) => {
    switch (model) {
      case 'Random Forest': return 'from-green-500 to-emerald-500';
      case 'XGBoost': return 'from-purple-500 to-indigo-500';
      case 'SVR': return 'from-blue-500 to-cyan-500';
      case 'GBM': return 'from-orange-500 to-red-500';
      case 'ARIMA': return 'from-pink-500 to-rose-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-green-400';
    if (confidence >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getPredictionDirection = (predicted: number, current: number) => {
    const change = ((predicted - current) / current) * 100;
    return {
      direction: change >= 0 ? 'UP' : 'DOWN',
      percentage: Math.abs(change),
      color: change >= 0 ? 'text-green-400' : 'text-red-400'
    };
  };

  const averagePrediction = predictions.reduce((sum, p) => sum + p.predictedPrice, 0) / predictions.length;
  const averageConfidence = predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length;
  
  const consensusDirection = getPredictionDirection(averagePrediction, currentPrice);

  const filteredPredictions = selectedModel === 'all' ? predictions : predictions.filter(p => p.model === selectedModel);

  return (
    <div className="space-y-6">
      {/* Header with Model Selection */}
      <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center">
              <Brain className="w-6 h-6 mr-3 text-purple-400" />
              AI Prediction Models
            </h2>
            <p className="text-gray-300">Advanced machine learning models analyzing price movements</p>
          </div>
          
          {/* Model Filter */}
          <div className="flex flex-wrap gap-2 mt-4 lg:mt-0">
            <button
              onClick={() => setSelectedModel('all')}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                selectedModel === 'all'
                  ? 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white'
                  : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
              }`}
            >
              All Models
            </button>
            {predictions.map((pred) => (
              <button
                key={pred.model}
                onClick={() => setSelectedModel(pred.model)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  selectedModel === pred.model
                    ? 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white'
                    : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                }`}
              >
                {pred.model}
              </button>
            ))}
          </div>
        </div>

        {/* Consensus Prediction */}
        {selectedModel === 'all' && (
          <div className="bg-gradient-to-br from-purple-500/20 to-indigo-500/20 border border-purple-500/30 rounded-xl p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white flex items-center">
                <Target className="w-5 h-5 mr-2 text-purple-400" />
                Consensus Prediction
              </h3>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                consensusDirection.direction === 'UP' 
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}>
                {consensusDirection.direction} {consensusDirection.percentage.toFixed(2)}%
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-gray-300 text-sm mb-1">Average Prediction</p>
                <p className="text-2xl font-bold text-white">{currencySymbol}{averagePrediction.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-300 text-sm mb-1">Current Price</p>
                <p className="text-2xl font-bold text-white">{currencySymbol}{currentPrice.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-gray-300 text-sm mb-1">Avg Confidence</p>
                <p className={`text-2xl font-bold ${getConfidenceColor(averageConfidence)}`}>
                  {averageConfidence.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Individual Model Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredPredictions.map((prediction) => {
          const direction = getPredictionDirection(prediction.predictedPrice, currentPrice);
          
          return (
            <div
              key={prediction.model}
              className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm hover:border-gray-600/50 transition-all duration-300"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className={`bg-gradient-to-r ${getModelColor(prediction.model)} p-2 rounded-lg mr-3`}>
                    {getModelIcon(prediction.model)}
                  </div>
                  <h3 className="text-lg font-bold text-white">{prediction.model}</h3>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                  prediction.confidence >= 80 
                    ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                    : prediction.confidence >= 60
                    ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                    : 'bg-red-500/20 text-red-400 border border-red-500/30'
                }`}>
                  {prediction.confidence.toFixed(1)}% confidence
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                  <p className="text-gray-400 text-sm mb-1">Predicted Price</p>
                  <p className="text-xl font-bold text-white">{currencySymbol}{prediction.predictedPrice.toFixed(2)}</p>
                </div>
                <div className="text-center p-3 bg-gray-800/50 rounded-lg">
                  <p className="text-gray-400 text-sm mb-1">Expected Change</p>
                  <p className={`text-xl font-bold ${direction.color}`}>
                    {direction.direction === 'UP' ? '+' : '-'}{direction.percentage.toFixed(2)}%
                  </p>
                </div>
              </div>

              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-400 mb-2">
                  <span>Accuracy Score</span>
                  <span>{prediction.accuracy}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full bg-gradient-to-r ${getModelColor(prediction.model)}`}
                    style={{ width: `${prediction.accuracy}%` }}
                  ></div>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-700/50">
                <p className="text-gray-300 text-sm">
                  <strong>Key Factors:</strong> {prediction.keyFactors.join(', ')}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Model Performance Comparison */}
      {selectedModel === 'all' && (
        <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-blue-400" />
            Model Performance Comparison
          </h3>
          
          <div className="space-y-4">
            {predictions.map((pred) => (
              <div key={pred.model} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                <div className="flex items-center">
                  <div className={`bg-gradient-to-r ${getModelColor(pred.model)} p-2 rounded-lg mr-3`}>
                    {getModelIcon(pred.model)}
                  </div>
                  <span className="font-medium text-white">{pred.model}</span>
                </div>
                
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <p className="text-xs text-gray-400">Accuracy</p>
                    <p className={`font-bold ${getConfidenceColor(pred.accuracy)}`}>{pred.accuracy}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-gray-400">Confidence</p>
                    <p className={`font-bold ${getConfidenceColor(pred.confidence)}`}>{pred.confidence.toFixed(1)}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-gray-400">Prediction</p>
                    <p className="font-bold text-white">{currencySymbol}{pred.predictedPrice.toFixed(2)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionModels;