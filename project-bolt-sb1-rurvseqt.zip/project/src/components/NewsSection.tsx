import React, { useState } from 'react';
import { Newspaper, Calendar, ExternalLink, TrendingUp, TrendingDown } from 'lucide-react';
import { getNewsForStock } from '../data/mockData';

interface NewsSectionProps {
  symbol: string;
}

const NewsSection: React.FC<NewsSectionProps> = ({ symbol }) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'earnings' | 'analyst' | 'market'>('all');

  const news = getNewsForStock(symbol);
  
  const filteredNews = selectedCategory === 'all' 
    ? news 
    : news.filter(item => item.category === selectedCategory);

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-400 bg-green-500/20 border-green-500/30';
      case 'negative': return 'text-red-400 bg-red-500/20 border-red-500/30';
      case 'neutral': return 'text-gray-400 bg-gray-500/20 border-gray-500/30';
      default: return 'text-gray-400 bg-gray-500/20 border-gray-500/30';
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return <TrendingUp className="w-4 h-4" />;
      case 'negative': return <TrendingDown className="w-4 h-4" />;
      default: return <TrendingUp className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-700/50 rounded-xl p-6 backdrop-blur-sm">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2 flex items-center">
            <Newspaper className="w-6 h-6 mr-3 text-green-400" />
            Latest News & Analysis
          </h2>
          <p className="text-gray-300">Market sentiment and key developments for {symbol}</p>
        </div>
        
        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mt-4 lg:mt-0">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
              selectedCategory === 'all'
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
                : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
            }`}
          >
            All News
          </button>
          <button
            onClick={() => setSelectedCategory('earnings')}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
              selectedCategory === 'earnings'
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
                : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
            }`}
          >
            Earnings
          </button>
          <button
            onClick={() => setSelectedCategory('analyst')}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
              selectedCategory === 'analyst'
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
                : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
            }`}
          >
            Analyst Reports
          </button>
          <button
            onClick={() => setSelectedCategory('market')}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
              selectedCategory === 'market'
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
                : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
            }`}
          >
            Market News
          </button>
        </div>
      </div>

      {/* News Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredNews.map((item) => (
          <div
            key={item.id}
            className="bg-gray-800/50 border border-gray-700/30 rounded-xl p-6 hover:border-gray-600/50 transition-all duration-300 group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className={`px-2 py-1 rounded-full text-xs font-medium border ${getSentimentColor(item.sentiment)}`}>
                  <div className="flex items-center">
                    {getSentimentIcon(item.sentiment)}
                    <span className="ml-1 capitalize">{item.sentiment}</span>
                  </div>
                </div>
                <span className="text-xs text-gray-400 bg-gray-700/50 px-2 py-1 rounded-full capitalize">
                  {item.category}
                </span>
              </div>
              <div className="flex items-center text-gray-400 text-sm">
                <Calendar className="w-4 h-4 mr-1" />
                {item.publishedAt}
              </div>
            </div>

            <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-blue-300 transition-colors duration-300">
              {item.title}
            </h3>
            
            <p className="text-gray-300 text-sm mb-4 line-clamp-3">
              {item.summary}
            </p>

            <div className="flex items-center justify-between">
              <div className="flex items-center text-sm text-gray-400">
                <span className="font-medium text-gray-300">{item.source}</span>
                <span className="mx-2">•</span>
                <span>Impact: {item.impactScore}/10</span>
              </div>
              <button className="flex items-center text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors duration-300">
                Read More
                <ExternalLink className="w-4 h-4 ml-1" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Market Sentiment Summary */}
      <div className="mt-8 pt-6 border-t border-gray-700/50">
        <h3 className="text-lg font-semibold text-white mb-4">Market Sentiment Analysis</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
            <div className="text-2xl font-bold text-green-400 mb-2">
              {news.filter(n => n.sentiment === 'positive').length}
            </div>
            <div className="text-green-300 text-sm">Positive News</div>
          </div>
          
          <div className="text-center p-4 bg-gray-500/10 border border-gray-500/20 rounded-xl">
            <div className="text-2xl font-bold text-gray-400 mb-2">
              {news.filter(n => n.sentiment === 'neutral').length}
            </div>
            <div className="text-gray-300 text-sm">Neutral News</div>
          </div>
          
          <div className="text-center p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
            <div className="text-2xl font-bold text-red-400 mb-2">
              {news.filter(n => n.sentiment === 'negative').length}
            </div>
            <div className="text-red-300 text-sm">Negative News</div>
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <p className="text-gray-300 text-sm">
            Overall Sentiment: <span className="font-bold text-green-400">Bullish</span>
            <span className="mx-2">•</span>
            Market Confidence: <span className="font-bold text-blue-400">High</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default NewsSection;