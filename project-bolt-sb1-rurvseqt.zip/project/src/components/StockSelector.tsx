import React, { useState } from 'react';
import { Search, TrendingUp, Star, Building2, X, Plus } from 'lucide-react';

interface StockSelectorProps {
  onStockSelect: (symbol: string) => void;
  selectedStocks?: string[];
  onMultiStockSelect?: (symbols: string[]) => void;
}

const popularStocks = [
  { symbol: 'AAPL', name: 'Apple Inc.', sector: 'Technology', price: 175.84, change: 2.34 },
  { symbol: 'MSFT', name: 'Microsoft Corp.', sector: 'Technology', price: 329.04, change: 1.67 },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', sector: 'Technology', price: 127.18, change: -0.82 },
  { symbol: 'TSLA', name: 'Tesla Inc.', sector: 'Automotive', price: 240.83, change: 3.21 },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', sector: 'E-commerce', price: 136.37, change: 1.45 },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', sector: 'Semiconductors', price: 451.02, change: 4.67 }
];

const indianStocks = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', sector: 'Energy', price: 2847.50, change: 1.23 },
  { symbol: 'TCS', name: 'Tata Consultancy Services', sector: 'IT Services', price: 3621.80, change: 2.15 },
  { symbol: 'INFY', name: 'Infosys Ltd.', sector: 'IT Services', price: 1456.75, change: -0.89 },
  { symbol: 'HDFCBANK', name: 'HDFC Bank Ltd.', sector: 'Banking', price: 1547.30, change: 0.67 }
];

const StockSelector: React.FC<StockSelectorProps> = ({ 
  onStockSelect, 
  selectedStocks = [], 
  onMultiStockSelect 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTab, setSelectedTab] = useState<'us' | 'indian'>('us');
  const [multiSelectMode, setMultiSelectMode] = useState(false);
  const [tempSelectedStocks, setTempSelectedStocks] = useState<string[]>(selectedStocks);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      const symbol = searchQuery.toUpperCase();
      if (multiSelectMode && onMultiStockSelect) {
        const newSelection = tempSelectedStocks.includes(symbol) 
          ? tempSelectedStocks.filter(s => s !== symbol)
          : [...tempSelectedStocks, symbol];
        setTempSelectedStocks(newSelection);
      } else {
        onStockSelect(symbol);
      }
      setSearchQuery('');
    }
  };

  const handleStockClick = (symbol: string) => {
    if (multiSelectMode && onMultiStockSelect) {
      const newSelection = tempSelectedStocks.includes(symbol) 
        ? tempSelectedStocks.filter(s => s !== symbol)
        : [...tempSelectedStocks, symbol];
      setTempSelectedStocks(newSelection);
    } else {
      onStockSelect(symbol);
    }
  };

  const applyMultiSelection = () => {
    if (onMultiStockSelect) {
      onMultiStockSelect(tempSelectedStocks);
      setMultiSelectMode(false);
    }
  };

  const cancelMultiSelection = () => {
    setTempSelectedStocks(selectedStocks);
    setMultiSelectMode(false);
  };

  const currentStocks = selectedTab === 'us' ? popularStocks : indianStocks;

  return (
    <div className="mb-12">
      {/* Multi-Select Controls */}
      <div className="flex justify-center mb-6">
        <div className="flex items-center space-x-4">
          {!multiSelectMode ? (
            <button
              onClick={() => setMultiSelectMode(true)}
              className="flex items-center px-4 py-2 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-lg font-medium hover:from-purple-600 hover:to-indigo-700 transition-all duration-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              Compare Multiple Stocks
            </button>
          ) : (
            <div className="flex items-center space-x-3">
              <span className="text-gray-300 text-sm">
                Selected: {tempSelectedStocks.length} stocks
              </span>
              <button
                onClick={applyMultiSelection}
                disabled={tempSelectedStocks.length === 0}
                className="px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg font-medium hover:from-green-600 hover:to-emerald-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Compare ({tempSelectedStocks.length})
              </button>
              <button
                onClick={cancelMultiSelection}
                className="px-4 py-2 bg-gray-600 text-white rounded-lg font-medium hover:bg-gray-700 transition-all duration-300"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Selected Stocks Display */}
      {multiSelectMode && tempSelectedStocks.length > 0 && (
        <div className="max-w-4xl mx-auto mb-6">
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4 backdrop-blur-sm">
            <h3 className="text-white font-medium mb-3">Selected for Comparison:</h3>
            <div className="flex flex-wrap gap-2">
              {tempSelectedStocks.map((symbol) => (
                <div
                  key={symbol}
                  className="flex items-center bg-gradient-to-r from-blue-500 to-purple-600 text-white px-3 py-1 rounded-full text-sm"
                >
                  <span>{symbol}</span>
                  <button
                    onClick={() => setTempSelectedStocks(prev => prev.filter(s => s !== symbol))}
                    className="ml-2 hover:bg-white/20 rounded-full p-0.5 transition-colors duration-200"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Search Bar */}
      <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={multiSelectMode ? "Add stock symbol to comparison" : "Enter stock symbol (e.g., AAPL, TCS, RELIANCE)"}
            className="w-full pl-12 pr-6 py-4 bg-gray-800/50 border border-gray-700/50 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm transition-all duration-300"
          />
          <button
            type="submit"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-all duration-300"
          >
            {multiSelectMode ? 'Add' : 'Analyze'}
          </button>
        </div>
      </form>

      {/* Stock Tabs */}
      <div className="flex justify-center mb-6">
        <div className="bg-gray-800/50 p-1 rounded-xl backdrop-blur-sm">
          <button
            onClick={() => setSelectedTab('us')}
            className={`px-6 py-2 rounded-lg font-medium transition-all duration-300 ${
              selectedTab === 'us'
                ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            US Stocks
          </button>
          <button
            onClick={() => setSelectedTab('indian')}
            className={`px-6 py-2 rounded-lg font-medium transition-all duration-300 ${
              selectedTab === 'indian'
                ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Indian Stocks
          </button>
        </div>
      </div>

      {/* Popular Stocks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
        {currentStocks.map((stock) => (
          <button
            key={stock.symbol}
            onClick={() => handleStockClick(stock.symbol)}
            className={`bg-gradient-to-br from-gray-800/80 to-gray-900/80 border rounded-xl p-6 text-left hover:from-gray-700/80 hover:to-gray-800/80 transition-all duration-300 backdrop-blur-sm group relative ${
              multiSelectMode && tempSelectedStocks.includes(stock.symbol)
                ? 'border-blue-500 bg-blue-500/10'
                : 'border-gray-700/50 hover:border-blue-500/30'
            }`}
          >
            {multiSelectMode && tempSelectedStocks.includes(stock.symbol) && (
              <div className="absolute top-2 right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs">✓</span>
              </div>
            )}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center">
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg mr-3 group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-300">
                  <Building2 className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">{stock.symbol}</h3>
                  <p className="text-gray-400 text-sm">{stock.sector}</p>
                </div>
              </div>
              <Star className="w-4 h-4 text-gray-500 group-hover:text-yellow-400 transition-colors duration-300" />
            </div>
            
            <p className="text-gray-300 text-sm mb-3 line-clamp-1">{stock.name}</p>
            
            <div className="flex items-center justify-between">
              <span className="text-xl font-bold text-white">
                {selectedTab === 'indian' ? '₹' : '$'}{stock.price.toFixed(2)}
              </span>
              <div className={`flex items-center ${stock.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                <TrendingUp className={`w-4 h-4 mr-1 ${stock.change < 0 ? 'rotate-180' : ''}`} />
                <span className="font-medium">{stock.change >= 0 ? '+' : ''}{stock.change}%</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default StockSelector;