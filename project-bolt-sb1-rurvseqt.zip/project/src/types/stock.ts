export interface StockData {
  symbol: string;
  name: string;
  currentPrice: number;
  dailyChange: number;
  weeklyChange?: number;
  monthlyChange?: number;
  ytdChange?: number;
  marketCap: string;
  volume: string;
  high52w: number;
  low52w: number;
  peRatio: number;
  volatility: number;
  beta?: number;
  sharpeRatio?: number;
  supportLevel: number;
  resistanceLevel: number;
  technicalIndicators: {
    rsi: number;
    macd: number;
    bollingerPosition: number;
  };
  movingAverages: {
    [key: string]: number;
  };
}

export interface PredictionResult {
  model: string;
  predictedPrice: number;
  confidence: number;
  accuracy: number;
  keyFactors: string[];
  timeframe: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  publishedAt: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  category: 'earnings' | 'analyst' | 'market';
  impactScore: number;
  url?: string;
}