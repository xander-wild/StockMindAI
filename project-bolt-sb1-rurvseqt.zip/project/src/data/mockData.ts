import { StockData, PredictionResult, NewsItem } from '../types/stock';

// Function to generate relevant news for any stock
export const getNewsForStock = (symbol: string): NewsItem[] => {
  // If we have specific news for this stock, return it
  if (mockNews[symbol]) {
    return mockNews[symbol];
  }
  
  // Generate relevant news for the stock
  const isIndianStock = ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'WIPRO', 'ICICIBANK', 'SBIN', 'ITC', 'HINDUNILVR', 'BAJFINANCE'].includes(symbol);
  
  if (isIndianStock) {
    return [
      {
        id: `${symbol}-1`,
        title: `${symbol} Reports Strong Quarterly Performance`,
        summary: `${symbol} posted impressive quarterly results with strong revenue growth and improved margins, beating analyst expectations across key metrics.`,
        source: 'Economic Times',
        publishedAt: '2 hours ago',
        sentiment: 'positive',
        category: 'earnings',
        impactScore: 8
      },
      {
        id: `${symbol}-2`,
        title: `Analysts Upgrade ${symbol} on Strong Fundamentals`,
        summary: `Leading brokerage firms have upgraded ${symbol} citing robust business fundamentals and positive outlook for the sector.`,
        source: 'Business Standard',
        publishedAt: '5 hours ago',
        sentiment: 'positive',
        category: 'analyst',
        impactScore: 7
      },
      {
        id: `${symbol}-3`,
        title: `${symbol} Announces Strategic Expansion Plans`,
        summary: `${symbol} unveiled ambitious expansion plans including new market entry and capacity enhancement initiatives to drive future growth.`,
        source: 'Moneycontrol',
        publishedAt: '1 day ago',
        sentiment: 'positive',
        category: 'market',
        impactScore: 6
      },
      {
        id: `${symbol}-4`,
        title: `Market Volatility Impacts ${symbol} Trading`,
        summary: `Recent market volatility has affected ${symbol} stock performance, with investors closely watching sector developments and policy changes.`,
        source: 'LiveMint',
        publishedAt: '1 day ago',
        sentiment: 'neutral',
        category: 'market',
        impactScore: 5
      }
    ];
  } else {
    // For US/International stocks
    return [
      {
        id: `${symbol}-1`,
        title: `${symbol} Beats Earnings Expectations`,
        summary: `${symbol} reported quarterly earnings that exceeded Wall Street expectations, driven by strong operational performance and market demand.`,
        source: 'Reuters',
        publishedAt: '3 hours ago',
        sentiment: 'positive',
        category: 'earnings',
        impactScore: 8
      },
      {
        id: `${symbol}-2`,
        title: `Wall Street Analysts Bullish on ${symbol}`,
        summary: `Multiple Wall Street analysts have raised their price targets for ${symbol}, citing strong competitive positioning and growth prospects.`,
        source: 'MarketWatch',
        publishedAt: '6 hours ago',
        sentiment: 'positive',
        category: 'analyst',
        impactScore: 7
      },
      {
        id: `${symbol}-3`,
        title: `${symbol} Faces Regulatory Scrutiny`,
        summary: `Regulatory authorities are examining ${symbol}'s business practices, which could impact future operations and market performance.`,
        source: 'Bloomberg',
        publishedAt: '12 hours ago',
        sentiment: 'negative',
        category: 'market',
        impactScore: 6
      },
      {
        id: `${symbol}-4`,
        title: `${symbol} Innovation Drive Shows Promise`,
        summary: `${symbol}'s recent investments in innovation and technology are showing positive results, positioning the company for future growth.`,
        source: 'CNBC',
        publishedAt: '1 day ago',
        sentiment: 'positive',
        category: 'market',
        impactScore: 7
      }
    ];
  }
};
export const mockStockData: Record<string, StockData> = {
  'AAPL': {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    currentPrice: 175.84,
    dailyChange: 2.34,
    weeklyChange: 3.24,
    monthlyChange: 8.76,
    ytdChange: 15.43,
    marketCap: '$2.7T',
    volume: '52.3M',
    high52w: 199.62,
    low52w: 124.17,
    peRatio: 28.7,
    volatility: 24.5,
    beta: 1.29,
    sharpeRatio: 0.85,
    supportLevel: 168.50,
    resistanceLevel: 185.20,
    technicalIndicators: {
      rsi: 58.4,
      macd: 1.23,
      bollingerPosition: 67.8
    },
    movingAverages: {
      'MA-20': 172.45,
      'MA-50': 168.92,
      'MA-100': 162.78,
      'MA-200': 155.34
    }
  },
  'MSFT': {
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    currentPrice: 329.04,
    dailyChange: 1.67,
    weeklyChange: 2.89,
    monthlyChange: 6.45,
    ytdChange: 12.78,
    marketCap: '$2.4T',
    volume: '28.7M',
    high52w: 384.30,
    low52w: 245.61,
    peRatio: 32.1,
    volatility: 26.8,
    beta: 1.12,
    sharpeRatio: 0.92,
    supportLevel: 315.00,
    resistanceLevel: 345.50,
    technicalIndicators: {
      rsi: 62.1,
      macd: 2.45,
      bollingerPosition: 72.3
    },
    movingAverages: {
      'MA-20': 325.67,
      'MA-50': 318.23,
      'MA-100': 308.45,
      'MA-200': 295.12
    }
  },
  'GOOGL': {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    currentPrice: 127.18,
    dailyChange: -0.82,
    weeklyChange: 1.45,
    monthlyChange: 4.23,
    ytdChange: 8.91,
    marketCap: '$1.6T',
    volume: '35.2M',
    high52w: 151.55,
    low52w: 83.34,
    peRatio: 25.4,
    volatility: 28.2,
    beta: 1.05,
    sharpeRatio: 0.78,
    supportLevel: 122.50,
    resistanceLevel: 135.80,
    technicalIndicators: {
      rsi: 45.7,
      macd: -0.67,
      bollingerPosition: 42.1
    },
    movingAverages: {
      'MA-20': 129.34,
      'MA-50': 125.89,
      'MA-100': 118.67,
      'MA-200': 112.45
    }
  },
  'TSLA': {
    symbol: 'TSLA',
    name: 'Tesla Inc.',
    currentPrice: 240.83,
    dailyChange: 3.21,
    weeklyChange: 5.67,
    monthlyChange: 12.34,
    ytdChange: 28.45,
    marketCap: '$765B',
    volume: '89.4M',
    high52w: 299.29,
    low52w: 138.80,
    peRatio: 65.2,
    volatility: 45.7,
    beta: 1.95,
    sharpeRatio: 0.64,
    supportLevel: 225.00,
    resistanceLevel: 265.50,
    technicalIndicators: {
      rsi: 68.9,
      macd: 3.78,
      bollingerPosition: 78.5
    },
    movingAverages: {
      'MA-20': 235.67,
      'MA-50': 228.45,
      'MA-100': 215.23,
      'MA-200': 198.67
    }
  },
  'RELIANCE': {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Limited',
    currentPrice: 2847.50,
    dailyChange: 1.23,
    weeklyChange: 2.45,
    monthlyChange: 5.67,
    ytdChange: 18.34,
    marketCap: '₹19.2L Cr',
    volume: '1.2Cr',
    high52w: 3024.90,
    low52w: 2220.30,
    peRatio: 28.4,
    volatility: 32.1,
    beta: 1.15,
    sharpeRatio: 0.73,
    supportLevel: 2780.00,
    resistanceLevel: 2920.00,
    technicalIndicators: {
      rsi: 54.2,
      macd: 15.67,
      bollingerPosition: 58.9
    },
    movingAverages: {
      'MA-20': 2825.45,
      'MA-50': 2789.23,
      'MA-100': 2745.67,
      'MA-200': 2678.90
    }
  },
  'TCS': {
    symbol: 'TCS',
    name: 'Tata Consultancy Services',
    currentPrice: 3621.80,
    dailyChange: 2.15,
    weeklyChange: 3.45,
    monthlyChange: 7.89,
    ytdChange: 22.34,
    marketCap: '₹13.2L Cr',
    volume: '45.6L',
    high52w: 4043.90,
    low52w: 2890.50,
    peRatio: 26.8,
    volatility: 28.4,
    beta: 0.95,
    sharpeRatio: 0.89,
    supportLevel: 3550.00,
    resistanceLevel: 3750.00,
    technicalIndicators: {
      rsi: 61.3,
      macd: 18.45,
      bollingerPosition: 68.7
    },
    movingAverages: {
      'MA-20': 3598.23,
      'MA-50': 3567.45,
      'MA-100': 3489.67,
      'MA-200': 3398.90
    }
  },
  'INFY': {
    symbol: 'INFY',
    name: 'Infosys Limited',
    currentPrice: 1456.75,
    dailyChange: -0.89,
    weeklyChange: 1.23,
    monthlyChange: 4.56,
    ytdChange: 16.78,
    marketCap: '₹6.1L Cr',
    volume: '78.9L',
    high52w: 1729.05,
    low52w: 1195.20,
    peRatio: 24.5,
    volatility: 31.2,
    beta: 1.08,
    sharpeRatio: 0.76,
    supportLevel: 1420.00,
    resistanceLevel: 1520.00,
    technicalIndicators: {
      rsi: 48.7,
      macd: -2.34,
      bollingerPosition: 45.2
    },
    movingAverages: {
      'MA-20': 1467.89,
      'MA-50': 1445.67,
      'MA-100': 1398.45,
      'MA-200': 1356.78
    }
  },
  'HDFCBANK': {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Limited',
    currentPrice: 1547.30,
    dailyChange: 0.67,
    weeklyChange: 2.34,
    monthlyChange: 6.78,
    ytdChange: 14.56,
    marketCap: '₹11.8L Cr',
    volume: '56.7L',
    high52w: 1725.90,
    low52w: 1363.55,
    peRatio: 19.8,
    volatility: 25.6,
    beta: 1.02,
    sharpeRatio: 0.82,
    supportLevel: 1510.00,
    resistanceLevel: 1590.00,
    technicalIndicators: {
      rsi: 55.8,
      macd: 5.67,
      bollingerPosition: 62.4
    },
    movingAverages: {
      'MA-20': 1534.56,
      'MA-50': 1521.34,
      'MA-100': 1498.78,
      'MA-200': 1467.89
    }
  }
};

export const mockPredictions: Record<string, PredictionResult[]> = {
  'AAPL': [
    {
      model: 'Random Forest',
      predictedPrice: 182.45,
      confidence: 84.7,
      accuracy: 87.2,
      keyFactors: ['Volume trends', 'Technical indicators', 'Market sentiment'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 179.23,
      confidence: 89.3,
      accuracy: 91.5,
      keyFactors: ['Price momentum', 'Trading volume', 'RSI patterns'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 178.67,
      confidence: 76.8,
      accuracy: 82.4,
      keyFactors: ['Support/resistance levels', 'Moving averages', 'Volatility'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 181.89,
      confidence: 82.1,
      accuracy: 85.7,
      keyFactors: ['Market trends', 'Technical analysis', 'Historical patterns'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 177.34,
      confidence: 71.5,
      accuracy: 78.9,
      keyFactors: ['Time series patterns', 'Seasonal trends', 'Price history'],
      timeframe: '1 day'
    }
  ],
  'MSFT': [
    {
      model: 'Random Forest',
      predictedPrice: 335.67,
      confidence: 86.2,
      accuracy: 88.9,
      keyFactors: ['Market momentum', 'Technical indicators', 'Volume analysis'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 332.45,
      confidence: 91.7,
      accuracy: 93.2,
      keyFactors: ['Price patterns', 'Market volatility', 'Trading signals'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 330.89,
      confidence: 78.4,
      accuracy: 84.1,
      keyFactors: ['Support levels', 'Moving averages', 'Price trends'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 334.12,
      confidence: 83.9,
      accuracy: 87.3,
      keyFactors: ['Technical analysis', 'Market indicators', 'Price momentum'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 328.76,
      confidence: 73.2,
      accuracy: 79.8,
      keyFactors: ['Historical trends', 'Time series analysis', 'Seasonal patterns'],
      timeframe: '1 day'
    }
  ],
  'GOOGL': [
    {
      model: 'Random Forest',
      predictedPrice: 129.87,
      confidence: 81.5,
      accuracy: 84.7,
      keyFactors: ['Technical indicators', 'Market sentiment', 'Volume trends'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 131.23,
      confidence: 87.9,
      accuracy: 89.8,
      keyFactors: ['Price momentum', 'Market volatility', 'Trading patterns'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 128.45,
      confidence: 74.6,
      accuracy: 81.2,
      keyFactors: ['Support/resistance', 'Moving averages', 'Price trends'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 130.56,
      confidence: 79.8,
      accuracy: 83.4,
      keyFactors: ['Market trends', 'Technical analysis', 'Historical data'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 127.89,
      confidence: 68.7,
      accuracy: 76.3,
      keyFactors: ['Time series patterns', 'Price history', 'Seasonal trends'],
      timeframe: '1 day'
    }
  ],
  'TSLA': [
    {
      model: 'Random Forest',
      predictedPrice: 252.34,
      confidence: 79.4,
      accuracy: 82.1,
      keyFactors: ['Volume analysis', 'Technical indicators', 'Market sentiment'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 248.67,
      confidence: 85.6,
      accuracy: 88.3,
      keyFactors: ['Price momentum', 'Volatility patterns', 'Trading volume'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 245.89,
      confidence: 72.3,
      accuracy: 78.7,
      keyFactors: ['Support levels', 'Moving averages', 'Price volatility'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 251.45,
      confidence: 81.7,
      accuracy: 84.9,
      keyFactors: ['Market trends', 'Technical patterns', 'Historical analysis'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 243.12,
      confidence: 66.8,
      accuracy: 74.5,
      keyFactors: ['Time series analysis', 'Historical trends', 'Seasonal patterns'],
      timeframe: '1 day'
    }
  ],
  'RELIANCE': [
    {
      model: 'Random Forest',
      predictedPrice: 2889.45,
      confidence: 83.2,
      accuracy: 86.4,
      keyFactors: ['Market momentum', 'Technical indicators', 'Volume trends'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 2876.23,
      confidence: 88.7,
      accuracy: 91.1,
      keyFactors: ['Price patterns', 'Market volatility', 'Trading signals'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 2865.78,
      confidence: 76.9,
      accuracy: 82.8,
      keyFactors: ['Support/resistance', 'Moving averages', 'Price trends'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 2882.67,
      confidence: 81.4,
      accuracy: 85.2,
      keyFactors: ['Technical analysis', 'Market indicators', 'Historical data'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 2859.34,
      confidence: 71.6,
      accuracy: 78.9,
      keyFactors: ['Time series patterns', 'Historical trends', 'Seasonal analysis'],
      timeframe: '1 day'
    }
  ],
  'TCS': [
    {
      model: 'Random Forest',
      predictedPrice: 3689.45,
      confidence: 87.3,
      accuracy: 89.6,
      keyFactors: ['IT sector trends', 'Technical indicators', 'Volume analysis'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 3675.23,
      confidence: 91.8,
      accuracy: 93.4,
      keyFactors: ['Price momentum', 'Sector performance', 'Market volatility'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 3658.67,
      confidence: 79.5,
      accuracy: 84.7,
      keyFactors: ['Support levels', 'Moving averages', 'Technical patterns'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 3682.89,
      confidence: 84.7,
      accuracy: 87.9,
      keyFactors: ['Market trends', 'Earnings outlook', 'Technical analysis'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 3645.34,
      confidence: 73.8,
      accuracy: 80.2,
      keyFactors: ['Historical patterns', 'Time series analysis', 'Seasonal trends'],
      timeframe: '1 day'
    }
  ],
  'INFY': [
    {
      model: 'Random Forest',
      predictedPrice: 1478.56,
      confidence: 82.4,
      accuracy: 85.8,
      keyFactors: ['IT sector momentum', 'Technical indicators', 'Volume trends'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 1465.89,
      confidence: 88.6,
      accuracy: 90.3,
      keyFactors: ['Price patterns', 'Market sentiment', 'Sector analysis'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 1452.34,
      confidence: 76.2,
      accuracy: 81.9,
      keyFactors: ['Support/resistance', 'Moving averages', 'Volatility'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 1471.23,
      confidence: 80.9,
      accuracy: 84.5,
      keyFactors: ['Technical patterns', 'Market trends', 'Historical data'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 1448.67,
      confidence: 69.7,
      accuracy: 76.8,
      keyFactors: ['Time series patterns', 'Historical trends', 'Price cycles'],
      timeframe: '1 day'
    }
  ],
  'HDFCBANK': [
    {
      model: 'Random Forest',
      predictedPrice: 1567.89,
      confidence: 85.6,
      accuracy: 88.2,
      keyFactors: ['Banking sector trends', 'Technical indicators', 'Volume analysis'],
      timeframe: '1 day'
    },
    {
      model: 'XGBoost',
      predictedPrice: 1559.34,
      confidence: 89.4,
      accuracy: 91.7,
      keyFactors: ['Price momentum', 'Financial metrics', 'Market sentiment'],
      timeframe: '1 day'
    },
    {
      model: 'SVR',
      predictedPrice: 1552.78,
      confidence: 78.9,
      accuracy: 83.6,
      keyFactors: ['Support levels', 'Moving averages', 'Technical patterns'],
      timeframe: '1 day'
    },
    {
      model: 'GBM',
      predictedPrice: 1563.45,
      confidence: 83.2,
      accuracy: 86.8,
      keyFactors: ['Market trends', 'Banking sector analysis', 'Technical indicators'],
      timeframe: '1 day'
    },
    {
      model: 'ARIMA',
      predictedPrice: 1548.90,
      confidence: 72.5,
      accuracy: 79.4,
      keyFactors: ['Historical patterns', 'Time series analysis', 'Price trends'],
      timeframe: '1 day'
    }
  ]
};

export const mockNews: Record<string, NewsItem[]> = {
  'AAPL': [
    {
      id: '1',
      title: 'Apple Reports Strong Q4 Earnings, Beats Revenue Expectations',
      summary: 'Apple Inc. reported quarterly revenue of $89.5 billion, surpassing analyst expectations of $87.2 billion. iPhone sales showed resilience despite market headwinds.',
      source: 'Reuters',
      publishedAt: '2 hours ago',
      sentiment: 'positive',
      category: 'earnings',
      impactScore: 9
    },
    {
      id: '2',
      title: 'Morgan Stanley Upgrades Apple to Overweight, Raises Price Target',
      summary: 'Morgan Stanley analysts upgraded Apple stock citing strong services growth and potential AI integration benefits. Price target raised to $190.',
      source: 'MarketWatch',
      publishedAt: '5 hours ago',
      sentiment: 'positive',
      category: 'analyst',
      impactScore: 7
    },
    {
      id: '3',
      title: 'Apple Vision Pro Sales Below Initial Expectations',
      summary: 'Industry reports suggest Apple Vision Pro sales have been slower than anticipated, raising questions about AR/VR market adoption timeline.',
      source: 'TechCrunch',
      publishedAt: '1 day ago',
      sentiment: 'negative',
      category: 'market',
      impactScore: 6
    },
    {
      id: '4',
      title: 'Apple Announces New AI Features for iOS 18',
      summary: 'Apple unveiled significant AI enhancements coming to iOS 18, including improved Siri capabilities and on-device machine learning features.',
      source: 'Apple Inc.',
      publishedAt: '1 day ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 8
    }
  ],
  'MSFT': [
    {
      id: '1',
      title: 'Microsoft Azure Revenue Grows 29%, Cloud Dominance Continues',
      summary: 'Microsoft reported strong Azure growth of 29% year-over-year, maintaining its position as a leading cloud services provider.',
      source: 'Bloomberg',
      publishedAt: '3 hours ago',
      sentiment: 'positive',
      category: 'earnings',
      impactScore: 9
    },
    {
      id: '2',
      title: 'Goldman Sachs Maintains Buy Rating on Microsoft',
      summary: 'Goldman Sachs reiterated its buy rating on Microsoft, citing strong fundamentals in cloud computing and AI integration.',
      source: 'Goldman Sachs',
      publishedAt: '6 hours ago',
      sentiment: 'positive',
      category: 'analyst',
      impactScore: 7
    },
    {
      id: '3',
      title: 'Microsoft Copilot Usage Surpasses 1 Million Enterprise Users',
      summary: 'Microsoft announced that its AI-powered Copilot has been adopted by over 1 million enterprise users, driving productivity gains.',
      source: 'Microsoft',
      publishedAt: '1 day ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 8
    }
  ],
  'GOOGL': [
    {
      id: '1',
      title: 'Alphabet Faces Regulatory Challenges in EU Market',
      summary: 'European regulators are considering additional restrictions on Alphabet\'s search and advertising practices, potentially impacting revenue.',
      source: 'Financial Times',
      publishedAt: '4 hours ago',
      sentiment: 'negative',
      category: 'market',
      impactScore: 7
    },
    {
      id: '2',
      title: 'Google Cloud Shows Strong Growth Despite Competition',
      summary: 'Google Cloud revenue increased 28% year-over-year, though still trails behind AWS and Microsoft Azure in market share.',
      source: 'CNBC',
      publishedAt: '8 hours ago',
      sentiment: 'neutral',
      category: 'earnings',
      impactScore: 6
    },
    {
      id: '3',
      title: 'Analyst Downgrades Alphabet Citing AI Competition Concerns',
      summary: 'Key analyst firm downgrades Alphabet stock, expressing concerns about increasing competition in AI and search markets.',
      source: 'Barron\'s',
      publishedAt: '1 day ago',
      sentiment: 'negative',
      category: 'analyst',
      impactScore: 8
    }
  ],
  'TSLA': [
    {
      id: '1',
      title: 'Tesla Delivers Record Q4 Vehicle Deliveries',
      summary: 'Tesla announced record quarterly vehicle deliveries of 484,507 vehicles, exceeding analyst expectations and previous company records.',
      source: 'Tesla',
      publishedAt: '1 hour ago',
      sentiment: 'positive',
      category: 'earnings',
      impactScore: 9
    },
    {
      id: '2',
      title: 'Wedbush Raises Tesla Price Target on Autonomous Driving Progress',
      summary: 'Wedbush Securities increased Tesla price target to $315, citing significant progress in full self-driving capabilities.',
      source: 'Wedbush',
      publishedAt: '4 hours ago',
      sentiment: 'positive',
      category: 'analyst',
      impactScore: 8
    },
    {
      id: '3',
      title: 'Tesla Faces Production Challenges at Berlin Gigafactory',
      summary: 'Reports indicate Tesla\'s Berlin facility is experiencing production bottlenecks, potentially impacting European delivery timelines.',
      source: 'Reuters',
      publishedAt: '12 hours ago',
      sentiment: 'negative',
      category: 'market',
      impactScore: 6
    }
  ],
  'RELIANCE': [
    {
      id: '1',
      title: 'Reliance Industries Reports Strong Quarterly Results',
      summary: 'Reliance Industries posted strong quarterly earnings driven by robust performance in petrochemicals and retail segments.',
      source: 'Economic Times',
      publishedAt: '2 hours ago',
      sentiment: 'positive',
      category: 'earnings',
      impactScore: 9
    },
    {
      id: '2',
      title: 'CLSA Upgrades Reliance to Outperform',
      summary: 'CLSA upgraded Reliance Industries to outperform rating, citing strong fundamentals and digital business growth potential.',
      source: 'CLSA',
      publishedAt: '6 hours ago',
      sentiment: 'positive',
      category: 'analyst',
      impactScore: 7
    },
    {
      id: '3',
      title: 'Reliance Jio Adds 12.8 Million Subscribers in Q4',
      summary: 'Jio continued its subscriber growth momentum, adding 12.8 million new users and maintaining its position as India\'s largest telecom operator.',
      source: 'Business Standard',
      publishedAt: '1 day ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 8
    }
  ],
  'TCS': [
    {
      id: '1',
      title: 'TCS Reports Record Quarterly Revenue of ₹59,381 Crores',
      summary: 'Tata Consultancy Services posted strong Q3 results with 4.1% sequential growth in constant currency terms, driven by robust demand across all verticals.',
      source: 'Economic Times',
      publishedAt: '1 hour ago',
      sentiment: 'positive',
      category: 'earnings',
      impactScore: 9
    },
    {
      id: '2',
      title: 'Morgan Stanley Raises TCS Target Price to ₹4,200',
      summary: 'Morgan Stanley upgraded TCS citing strong deal pipeline, improved margins, and leadership position in digital transformation services.',
      source: 'Moneycontrol',
      publishedAt: '4 hours ago',
      sentiment: 'positive',
      category: 'analyst',
      impactScore: 8
    },
    {
      id: '3',
      title: 'TCS Wins $2.25 Billion Deal from UK Government',
      summary: 'TCS secured a major multi-year contract to modernize UK government digital infrastructure, strengthening its position in the European market.',
      source: 'Business Standard',
      publishedAt: '8 hours ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 9
    },
    {
      id: '4',
      title: 'TCS Announces 15,000 Fresh Hiring for FY24',
      summary: 'TCS plans to hire 15,000 freshers in FY24, indicating strong business confidence and growth expectations in the IT services sector.',
      source: 'LiveMint',
      publishedAt: '12 hours ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 7
    }
  ],
  'INFY': [
    {
      id: '1',
      title: 'Infosys Maintains FY24 Revenue Growth Guidance at 1-3.5%',
      summary: 'Infosys retained its revenue growth guidance despite challenging macro environment, showing confidence in its digital transformation capabilities.',
      source: 'Economic Times',
      publishedAt: '2 hours ago',
      sentiment: 'neutral',
      category: 'earnings',
      impactScore: 7
    },
    {
      id: '2',
      title: 'Infosys Cobalt Wins Major Banking Transformation Deal',
      summary: 'Infosys secured a significant cloud transformation contract from a leading European bank, leveraging its Cobalt cloud platform.',
      source: 'Business Standard',
      publishedAt: '6 hours ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 8
    },
    {
      id: '3',
      title: 'Analysts Mixed on Infosys After Q3 Results',
      summary: 'While Infosys beat earnings expectations, analysts remain cautious about demand environment and pricing pressures in key markets.',
      source: 'Moneycontrol',
      publishedAt: '1 day ago',
      sentiment: 'neutral',
      category: 'analyst',
      impactScore: 6
    },
    {
      id: '4',
      title: 'Infosys Expands AI and Automation Capabilities',
      summary: 'Infosys announced new AI-powered automation solutions and partnerships to help clients accelerate their digital transformation journey.',
      source: 'LiveMint',
      publishedAt: '1 day ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 7
    }
  ],
  'HDFCBANK': [
    {
      id: '1',
      title: 'HDFC Bank Q3 Net Profit Rises 20% to ₹16,372 Crores',
      summary: 'HDFC Bank reported strong quarterly results with 20% YoY growth in net profit, driven by healthy loan growth and improved asset quality.',
      source: 'Economic Times',
      publishedAt: '3 hours ago',
      sentiment: 'positive',
      category: 'earnings',
      impactScore: 9
    },
    {
      id: '2',
      title: 'RBI Approves HDFC Bank-HDFC Ltd Merger Timeline',
      summary: 'Reserve Bank of India provided clarity on the merger timeline between HDFC Bank and HDFC Ltd, removing regulatory uncertainty.',
      source: 'Business Standard',
      publishedAt: '5 hours ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 8
    },
    {
      id: '3',
      title: 'HDFC Bank Launches Digital Lending Platform',
      summary: 'HDFC Bank unveiled a new AI-powered digital lending platform to enhance customer experience and streamline loan processing.',
      source: 'Moneycontrol',
      publishedAt: '10 hours ago',
      sentiment: 'positive',
      category: 'market',
      impactScore: 6
    },
    {
      id: '4',
      title: 'Credit Rating Agencies Affirm HDFC Bank Ratings',
      summary: 'Major credit rating agencies reaffirmed HDFC Bank\'s high credit ratings, citing strong financial fundamentals and market position.',
      source: 'LiveMint',
      publishedAt: '1 day ago',
      sentiment: 'positive',
      category: 'analyst',
      impactScore: 7
    }
  ]
};